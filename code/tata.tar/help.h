#ifndef HELP_H
#define HELP_H

extern int help(int, char *[]);

#endif
